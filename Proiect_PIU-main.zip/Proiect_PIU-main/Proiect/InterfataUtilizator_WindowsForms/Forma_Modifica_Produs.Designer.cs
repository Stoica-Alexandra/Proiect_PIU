﻿namespace InterfataUtilizator_WindowsForms
{
    partial class Forma_Modifica_Produs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNume = new System.Windows.Forms.Label();
            this.lblCantitate = new System.Windows.Forms.Label();
            this.lblPret = new System.Windows.Forms.Label();
            this.txtNume = new System.Windows.Forms.TextBox();
            this.txtPret = new System.Windows.Forms.TextBox();
            this.btnAdauga = new System.Windows.Forms.Button();
            this.lblTitlu = new System.Windows.Forms.Label();
            this.lblTip = new System.Windows.Forms.Label();
            this.lblOptiuni = new System.Windows.Forms.Label();
            this.cbxTip = new System.Windows.Forms.ComboBox();
            this.txtCantitate = new System.Windows.Forms.TextBox();
            this.gbxOptiuni = new System.Windows.Forms.GroupBox();
            this.ckbNedefinit = new System.Windows.Forms.CheckBox();
            this.ckbReturUsor = new System.Windows.Forms.CheckBox();
            this.ckbDisponibilOnline = new System.Windows.Forms.CheckBox();
            this.ckbDisponibilFizic = new System.Windows.Forms.CheckBox();
            this.ckbPersonalizabil = new System.Windows.Forms.CheckBox();
            this.ckbGarantieExtinsa = new System.Windows.Forms.CheckBox();
            this.ckbTravelSize = new System.Windows.Forms.CheckBox();
            this.ckbNoName = new System.Windows.Forms.CheckBox();
            this.ckbBrand = new System.Windows.Forms.CheckBox();
            this.ckbPremium = new System.Windows.Forms.CheckBox();
            this.ckbHandmade = new System.Windows.Forms.CheckBox();
            this.ckbVegan = new System.Windows.Forms.CheckBox();
            this.ckbEditieLimitata = new System.Windows.Forms.CheckBox();
            this.ckbReciclabil = new System.Windows.Forms.CheckBox();
            this.gbxOptiuni.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNume
            // 
            this.lblNume.AutoSize = true;
            this.lblNume.BackColor = System.Drawing.Color.Transparent;
            this.lblNume.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNume.Location = new System.Drawing.Point(105, 88);
            this.lblNume.Name = "lblNume";
            this.lblNume.Size = new System.Drawing.Size(57, 22);
            this.lblNume.TabIndex = 0;
            this.lblNume.Text = "Nume";
            // 
            // lblCantitate
            // 
            this.lblCantitate.AutoSize = true;
            this.lblCantitate.BackColor = System.Drawing.Color.Transparent;
            this.lblCantitate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCantitate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCantitate.Location = new System.Drawing.Point(105, 138);
            this.lblCantitate.Name = "lblCantitate";
            this.lblCantitate.Size = new System.Drawing.Size(82, 22);
            this.lblCantitate.TabIndex = 2;
            this.lblCantitate.Text = "Cantitate";
            // 
            // lblPret
            // 
            this.lblPret.AutoSize = true;
            this.lblPret.BackColor = System.Drawing.Color.Transparent;
            this.lblPret.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPret.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPret.Location = new System.Drawing.Point(105, 188);
            this.lblPret.Name = "lblPret";
            this.lblPret.Size = new System.Drawing.Size(43, 22);
            this.lblPret.TabIndex = 3;
            this.lblPret.Text = "Preț";
            // 
            // txtNume
            // 
            this.txtNume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNume.Location = new System.Drawing.Point(285, 75);
            this.txtNume.Multiline = true;
            this.txtNume.Name = "txtNume";
            this.txtNume.Size = new System.Drawing.Size(250, 35);
            this.txtNume.TabIndex = 5;
            // 
            // txtPret
            // 
            this.txtPret.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPret.Location = new System.Drawing.Point(285, 175);
            this.txtPret.Multiline = true;
            this.txtPret.Name = "txtPret";
            this.txtPret.Size = new System.Drawing.Size(250, 35);
            this.txtPret.TabIndex = 9;
            // 
            // btnAdauga
            // 
            this.btnAdauga.BackColor = System.Drawing.Color.Purple;
            this.btnAdauga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAdauga.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAdauga.Location = new System.Drawing.Point(109, 524);
            this.btnAdauga.Name = "btnAdauga";
            this.btnAdauga.Size = new System.Drawing.Size(426, 54);
            this.btnAdauga.TabIndex = 10;
            this.btnAdauga.Text = "Adaugă";
            this.btnAdauga.UseVisualStyleBackColor = false;
            this.btnAdauga.Click += new System.EventHandler(this.btnAdauga_Click);
            // 
            // lblTitlu
            // 
            this.lblTitlu.AutoSize = true;
            this.lblTitlu.BackColor = System.Drawing.Color.Transparent;
            this.lblTitlu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitlu.Location = new System.Drawing.Point(230, 20);
            this.lblTitlu.Name = "lblTitlu";
            this.lblTitlu.Size = new System.Drawing.Size(184, 25);
            this.lblTitlu.TabIndex = 11;
            this.lblTitlu.Text = "Modificare produs";
            // 
            // lblTip
            // 
            this.lblTip.AutoSize = true;
            this.lblTip.BackColor = System.Drawing.Color.Transparent;
            this.lblTip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblTip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTip.Location = new System.Drawing.Point(105, 238);
            this.lblTip.Name = "lblTip";
            this.lblTip.Size = new System.Drawing.Size(96, 22);
            this.lblTip.TabIndex = 12;
            this.lblTip.Text = "Tip produs";
            // 
            // lblOptiuni
            // 
            this.lblOptiuni.AutoSize = true;
            this.lblOptiuni.BackColor = System.Drawing.Color.Transparent;
            this.lblOptiuni.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblOptiuni.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblOptiuni.Location = new System.Drawing.Point(105, 288);
            this.lblOptiuni.Name = "lblOptiuni";
            this.lblOptiuni.Size = new System.Drawing.Size(127, 22);
            this.lblOptiuni.TabIndex = 13;
            this.lblOptiuni.Text = "Opțiuni produs";
            // 
            // cbxTip
            // 
            this.cbxTip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbxTip.FormattingEnabled = true;
            this.cbxTip.Items.AddRange(new object[] {
            "Alimentar ",
            "Electronic ",
            "Vestimentar ",
            "Casnic ",
            "Sport ",
            "Carte ",
            "Jucarie ",
            "Sanatate ",
            "Mobila ",
            "Gradinarit ",
            "Cosmetic ",
            "Nedefinit"});
            this.cbxTip.Location = new System.Drawing.Point(285, 230);
            this.cbxTip.Name = "cbxTip";
            this.cbxTip.Size = new System.Drawing.Size(250, 30);
            this.cbxTip.TabIndex = 14;
            // 
            // txtCantitate
            // 
            this.txtCantitate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtCantitate.Location = new System.Drawing.Point(285, 125);
            this.txtCantitate.Multiline = true;
            this.txtCantitate.Name = "txtCantitate";
            this.txtCantitate.Size = new System.Drawing.Size(250, 35);
            this.txtCantitate.TabIndex = 15;
            // 
            // gbxOptiuni
            // 
            this.gbxOptiuni.Controls.Add(this.ckbNedefinit);
            this.gbxOptiuni.Controls.Add(this.ckbReturUsor);
            this.gbxOptiuni.Controls.Add(this.ckbDisponibilOnline);
            this.gbxOptiuni.Controls.Add(this.ckbDisponibilFizic);
            this.gbxOptiuni.Controls.Add(this.ckbPersonalizabil);
            this.gbxOptiuni.Controls.Add(this.ckbGarantieExtinsa);
            this.gbxOptiuni.Controls.Add(this.ckbTravelSize);
            this.gbxOptiuni.Controls.Add(this.ckbNoName);
            this.gbxOptiuni.Controls.Add(this.ckbBrand);
            this.gbxOptiuni.Controls.Add(this.ckbPremium);
            this.gbxOptiuni.Controls.Add(this.ckbHandmade);
            this.gbxOptiuni.Controls.Add(this.ckbVegan);
            this.gbxOptiuni.Controls.Add(this.ckbEditieLimitata);
            this.gbxOptiuni.Controls.Add(this.ckbReciclabil);
            this.gbxOptiuni.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gbxOptiuni.Location = new System.Drawing.Point(53, 313);
            this.gbxOptiuni.Name = "gbxOptiuni";
            this.gbxOptiuni.Size = new System.Drawing.Size(530, 196);
            this.gbxOptiuni.TabIndex = 16;
            this.gbxOptiuni.TabStop = false;
            // 
            // ckbNedefinit
            // 
            this.ckbNedefinit.AutoSize = true;
            this.ckbNedefinit.Location = new System.Drawing.Point(217, 157);
            this.ckbNedefinit.Name = "ckbNedefinit";
            this.ckbNedefinit.Size = new System.Drawing.Size(103, 26);
            this.ckbNedefinit.TabIndex = 13;
            this.ckbNedefinit.Text = "Nedefinit";
            this.ckbNedefinit.UseVisualStyleBackColor = true;
            this.ckbNedefinit.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbReturUsor
            // 
            this.ckbReturUsor.AutoSize = true;
            this.ckbReturUsor.Location = new System.Drawing.Point(218, 125);
            this.ckbReturUsor.Name = "ckbReturUsor";
            this.ckbReturUsor.Size = new System.Drawing.Size(116, 26);
            this.ckbReturUsor.TabIndex = 12;
            this.ckbReturUsor.Text = "Retur ușor";
            this.ckbReturUsor.UseVisualStyleBackColor = true;
            this.ckbReturUsor.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbDisponibilOnline
            // 
            this.ckbDisponibilOnline.AutoSize = true;
            this.ckbDisponibilOnline.Location = new System.Drawing.Point(17, 29);
            this.ckbDisponibilOnline.Name = "ckbDisponibilOnline";
            this.ckbDisponibilOnline.Size = new System.Drawing.Size(163, 26);
            this.ckbDisponibilOnline.TabIndex = 11;
            this.ckbDisponibilOnline.Text = "Disponibil online";
            this.ckbDisponibilOnline.UseVisualStyleBackColor = true;
            this.ckbDisponibilOnline.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbDisponibilFizic
            // 
            this.ckbDisponibilFizic.AutoSize = true;
            this.ckbDisponibilFizic.Location = new System.Drawing.Point(17, 157);
            this.ckbDisponibilFizic.Name = "ckbDisponibilFizic";
            this.ckbDisponibilFizic.Size = new System.Drawing.Size(145, 26);
            this.ckbDisponibilFizic.TabIndex = 10;
            this.ckbDisponibilFizic.Text = "Disponibil fizic";
            this.ckbDisponibilFizic.UseVisualStyleBackColor = true;
            this.ckbDisponibilFizic.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbPersonalizabil
            // 
            this.ckbPersonalizabil.AutoSize = true;
            this.ckbPersonalizabil.Location = new System.Drawing.Point(17, 61);
            this.ckbPersonalizabil.Name = "ckbPersonalizabil";
            this.ckbPersonalizabil.Size = new System.Drawing.Size(143, 26);
            this.ckbPersonalizabil.TabIndex = 9;
            this.ckbPersonalizabil.Text = "Personalizabil";
            this.ckbPersonalizabil.UseVisualStyleBackColor = true;
            this.ckbPersonalizabil.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbGarantieExtinsa
            // 
            this.ckbGarantieExtinsa.AutoSize = true;
            this.ckbGarantieExtinsa.Location = new System.Drawing.Point(17, 125);
            this.ckbGarantieExtinsa.Name = "ckbGarantieExtinsa";
            this.ckbGarantieExtinsa.Size = new System.Drawing.Size(163, 26);
            this.ckbGarantieExtinsa.TabIndex = 8;
            this.ckbGarantieExtinsa.Text = "Garanție extinsă";
            this.ckbGarantieExtinsa.UseVisualStyleBackColor = true;
            this.ckbGarantieExtinsa.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbTravelSize
            // 
            this.ckbTravelSize.AutoSize = true;
            this.ckbTravelSize.Location = new System.Drawing.Point(363, 61);
            this.ckbTravelSize.Name = "ckbTravelSize";
            this.ckbTravelSize.Size = new System.Drawing.Size(117, 26);
            this.ckbTravelSize.TabIndex = 7;
            this.ckbTravelSize.Text = "TravelSize";
            this.ckbTravelSize.UseVisualStyleBackColor = true;
            this.ckbTravelSize.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbNoName
            // 
            this.ckbNoName.AutoSize = true;
            this.ckbNoName.Location = new System.Drawing.Point(218, 93);
            this.ckbNoName.Name = "ckbNoName";
            this.ckbNoName.Size = new System.Drawing.Size(102, 26);
            this.ckbNoName.TabIndex = 6;
            this.ckbNoName.Text = "NoName";
            this.ckbNoName.UseVisualStyleBackColor = true;
            this.ckbNoName.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbBrand
            // 
            this.ckbBrand.AutoSize = true;
            this.ckbBrand.Location = new System.Drawing.Point(218, 61);
            this.ckbBrand.Name = "ckbBrand";
            this.ckbBrand.Size = new System.Drawing.Size(80, 26);
            this.ckbBrand.TabIndex = 5;
            this.ckbBrand.Text = "Brand";
            this.ckbBrand.UseVisualStyleBackColor = true;
            this.ckbBrand.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbPremium
            // 
            this.ckbPremium.AutoSize = true;
            this.ckbPremium.Location = new System.Drawing.Point(218, 29);
            this.ckbPremium.Name = "ckbPremium";
            this.ckbPremium.Size = new System.Drawing.Size(102, 26);
            this.ckbPremium.TabIndex = 4;
            this.ckbPremium.Text = "Premium";
            this.ckbPremium.UseVisualStyleBackColor = true;
            this.ckbPremium.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbHandmade
            // 
            this.ckbHandmade.AutoSize = true;
            this.ckbHandmade.Location = new System.Drawing.Point(363, 29);
            this.ckbHandmade.Name = "ckbHandmade";
            this.ckbHandmade.Size = new System.Drawing.Size(119, 26);
            this.ckbHandmade.TabIndex = 3;
            this.ckbHandmade.Text = "Handmade";
            this.ckbHandmade.UseVisualStyleBackColor = true;
            this.ckbHandmade.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbVegan
            // 
            this.ckbVegan.AutoSize = true;
            this.ckbVegan.Location = new System.Drawing.Point(363, 93);
            this.ckbVegan.Name = "ckbVegan";
            this.ckbVegan.Size = new System.Drawing.Size(84, 26);
            this.ckbVegan.TabIndex = 2;
            this.ckbVegan.Text = "Vegan";
            this.ckbVegan.UseVisualStyleBackColor = true;
            this.ckbVegan.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbEditieLimitata
            // 
            this.ckbEditieLimitata.AutoSize = true;
            this.ckbEditieLimitata.Location = new System.Drawing.Point(17, 93);
            this.ckbEditieLimitata.Name = "ckbEditieLimitata";
            this.ckbEditieLimitata.Size = new System.Drawing.Size(138, 26);
            this.ckbEditieLimitata.TabIndex = 1;
            this.ckbEditieLimitata.Text = "Ediție limitată";
            this.ckbEditieLimitata.UseVisualStyleBackColor = true;
            this.ckbEditieLimitata.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // ckbReciclabil
            // 
            this.ckbReciclabil.AutoSize = true;
            this.ckbReciclabil.Location = new System.Drawing.Point(363, 125);
            this.ckbReciclabil.Name = "ckbReciclabil";
            this.ckbReciclabil.Size = new System.Drawing.Size(109, 26);
            this.ckbReciclabil.TabIndex = 0;
            this.ckbReciclabil.Text = "Reciclabil";
            this.ckbReciclabil.UseVisualStyleBackColor = true;
            this.ckbReciclabil.CheckedChanged += new System.EventHandler(this.CkbOptiuni_CheckedChanged);
            // 
            // Forma_Modifica_Produs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(632, 614);
            this.Controls.Add(this.lblOptiuni);
            this.Controls.Add(this.gbxOptiuni);
            this.Controls.Add(this.txtCantitate);
            this.Controls.Add(this.cbxTip);
            this.Controls.Add(this.lblTip);
            this.Controls.Add(this.lblTitlu);
            this.Controls.Add(this.btnAdauga);
            this.Controls.Add(this.txtPret);
            this.Controls.Add(this.txtNume);
            this.Controls.Add(this.lblPret);
            this.Controls.Add(this.lblCantitate);
            this.Controls.Add(this.lblNume);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Forma_Modifica_Produs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modificare Produs";
            this.gbxOptiuni.ResumeLayout(false);
            this.gbxOptiuni.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNume;
        private System.Windows.Forms.Label lblCantitate;
        private System.Windows.Forms.Label lblPret;
        private System.Windows.Forms.TextBox txtNume;
        private System.Windows.Forms.TextBox txtPret;
        private System.Windows.Forms.Button btnAdauga;
        private System.Windows.Forms.Label lblTitlu;
        private System.Windows.Forms.Label lblTip;
        private System.Windows.Forms.Label lblOptiuni;
        private System.Windows.Forms.ComboBox cbxTip;
        private System.Windows.Forms.TextBox txtCantitate;
        private System.Windows.Forms.GroupBox gbxOptiuni;
        private System.Windows.Forms.CheckBox ckbReciclabil;
        private System.Windows.Forms.CheckBox ckbGarantieExtinsa;
        private System.Windows.Forms.CheckBox ckbTravelSize;
        private System.Windows.Forms.CheckBox ckbNoName;
        private System.Windows.Forms.CheckBox ckbBrand;
        private System.Windows.Forms.CheckBox ckbPremium;
        private System.Windows.Forms.CheckBox ckbHandmade;
        private System.Windows.Forms.CheckBox ckbVegan;
        private System.Windows.Forms.CheckBox ckbEditieLimitata;
        private System.Windows.Forms.CheckBox ckbPersonalizabil;
        private System.Windows.Forms.CheckBox ckbDisponibilOnline;
        private System.Windows.Forms.CheckBox ckbDisponibilFizic;
        private System.Windows.Forms.CheckBox ckbReturUsor;
        private System.Windows.Forms.CheckBox ckbNedefinit;
    }
}