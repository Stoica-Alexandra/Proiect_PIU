﻿namespace InterfataUtilizator_WindowsForms
{
    partial class Forma_Adauga_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNume = new System.Windows.Forms.Label();
            this.lblBuget = new System.Windows.Forms.Label();
            this.lblNrTelefon = new System.Windows.Forms.Label();
            this.lblCNP = new System.Windows.Forms.Label();
            this.lblPrenume = new System.Windows.Forms.Label();
            this.txtNume = new System.Windows.Forms.TextBox();
            this.txtPrenume = new System.Windows.Forms.TextBox();
            this.txtBuget = new System.Windows.Forms.TextBox();
            this.txtNrTelefon = new System.Windows.Forms.TextBox();
            this.txtCNP = new System.Windows.Forms.TextBox();
            this.btnAdauga = new System.Windows.Forms.Button();
            this.lblTitlu = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNume
            // 
            this.lblNume.AutoSize = true;
            this.lblNume.BackColor = System.Drawing.Color.Transparent;
            this.lblNume.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNume.Location = new System.Drawing.Point(105, 88);
            this.lblNume.Name = "lblNume";
            this.lblNume.Size = new System.Drawing.Size(57, 22);
            this.lblNume.TabIndex = 0;
            this.lblNume.Text = "Nume";
            // 
            // lblBuget
            // 
            this.lblBuget.AutoSize = true;
            this.lblBuget.BackColor = System.Drawing.Color.Transparent;
            this.lblBuget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblBuget.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblBuget.Location = new System.Drawing.Point(104, 285);
            this.lblBuget.Name = "lblBuget";
            this.lblBuget.Size = new System.Drawing.Size(57, 22);
            this.lblBuget.TabIndex = 1;
            this.lblBuget.Text = "Buget";
            // 
            // lblNrTelefon
            // 
            this.lblNrTelefon.AutoSize = true;
            this.lblNrTelefon.BackColor = System.Drawing.Color.Transparent;
            this.lblNrTelefon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNrTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNrTelefon.Location = new System.Drawing.Point(104, 235);
            this.lblNrTelefon.Name = "lblNrTelefon";
            this.lblNrTelefon.Size = new System.Drawing.Size(147, 22);
            this.lblNrTelefon.TabIndex = 2;
            this.lblNrTelefon.Text = "Număr de telefon";
            // 
            // lblCNP
            // 
            this.lblCNP.AutoSize = true;
            this.lblCNP.BackColor = System.Drawing.Color.Transparent;
            this.lblCNP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCNP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCNP.Location = new System.Drawing.Point(104, 185);
            this.lblCNP.Name = "lblCNP";
            this.lblCNP.Size = new System.Drawing.Size(48, 22);
            this.lblCNP.TabIndex = 3;
            this.lblCNP.Text = "CNP";
            // 
            // lblPrenume
            // 
            this.lblPrenume.AutoSize = true;
            this.lblPrenume.BackColor = System.Drawing.Color.Transparent;
            this.lblPrenume.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPrenume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPrenume.Location = new System.Drawing.Point(105, 138);
            this.lblPrenume.Name = "lblPrenume";
            this.lblPrenume.Size = new System.Drawing.Size(82, 22);
            this.lblPrenume.TabIndex = 4;
            this.lblPrenume.Text = "Prenume";
            // 
            // txtNume
            // 
            this.txtNume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNume.Location = new System.Drawing.Point(285, 75);
            this.txtNume.Multiline = true;
            this.txtNume.Name = "txtNume";
            this.txtNume.Size = new System.Drawing.Size(250, 35);
            this.txtNume.TabIndex = 5;
            // 
            // txtPrenume
            // 
            this.txtPrenume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPrenume.Location = new System.Drawing.Point(285, 125);
            this.txtPrenume.Multiline = true;
            this.txtPrenume.Name = "txtPrenume";
            this.txtPrenume.Size = new System.Drawing.Size(250, 35);
            this.txtPrenume.TabIndex = 6;
            // 
            // txtBuget
            // 
            this.txtBuget.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtBuget.Location = new System.Drawing.Point(285, 275);
            this.txtBuget.Multiline = true;
            this.txtBuget.Name = "txtBuget";
            this.txtBuget.Size = new System.Drawing.Size(250, 35);
            this.txtBuget.TabIndex = 7;
            // 
            // txtNrTelefon
            // 
            this.txtNrTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNrTelefon.Location = new System.Drawing.Point(285, 225);
            this.txtNrTelefon.Multiline = true;
            this.txtNrTelefon.Name = "txtNrTelefon";
            this.txtNrTelefon.Size = new System.Drawing.Size(250, 35);
            this.txtNrTelefon.TabIndex = 8;
            // 
            // txtCNP
            // 
            this.txtCNP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtCNP.Location = new System.Drawing.Point(285, 175);
            this.txtCNP.Multiline = true;
            this.txtCNP.Name = "txtCNP";
            this.txtCNP.Size = new System.Drawing.Size(250, 35);
            this.txtCNP.TabIndex = 9;
            // 
            // btnAdauga
            // 
            this.btnAdauga.BackColor = System.Drawing.Color.Purple;
            this.btnAdauga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAdauga.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAdauga.Location = new System.Drawing.Point(109, 340);
            this.btnAdauga.Name = "btnAdauga";
            this.btnAdauga.Size = new System.Drawing.Size(426, 54);
            this.btnAdauga.TabIndex = 10;
            this.btnAdauga.Text = "Adaugă";
            this.btnAdauga.UseVisualStyleBackColor = false;
            this.btnAdauga.Click += new System.EventHandler(this.btnAdauga_Click);
            // 
            // lblTitlu
            // 
            this.lblTitlu.AutoSize = true;
            this.lblTitlu.BackColor = System.Drawing.Color.Transparent;
            this.lblTitlu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitlu.Location = new System.Drawing.Point(230, 20);
            this.lblTitlu.Name = "lblTitlu";
            this.lblTitlu.Size = new System.Drawing.Size(163, 25);
            this.lblTitlu.TabIndex = 11;
            this.lblTitlu.Text = "Adăugare client";
            // 
            // Forma_Adauga_Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.lblTitlu);
            this.Controls.Add(this.btnAdauga);
            this.Controls.Add(this.txtCNP);
            this.Controls.Add(this.txtNrTelefon);
            this.Controls.Add(this.txtBuget);
            this.Controls.Add(this.txtPrenume);
            this.Controls.Add(this.txtNume);
            this.Controls.Add(this.lblPrenume);
            this.Controls.Add(this.lblCNP);
            this.Controls.Add(this.lblNrTelefon);
            this.Controls.Add(this.lblBuget);
            this.Controls.Add(this.lblNume);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Forma_Adauga_Client";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adăugare Client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNume;
        private System.Windows.Forms.Label lblBuget;
        private System.Windows.Forms.Label lblNrTelefon;
        private System.Windows.Forms.Label lblCNP;
        private System.Windows.Forms.Label lblPrenume;
        private System.Windows.Forms.TextBox txtNume;
        private System.Windows.Forms.TextBox txtPrenume;
        private System.Windows.Forms.TextBox txtBuget;
        private System.Windows.Forms.TextBox txtNrTelefon;
        private System.Windows.Forms.TextBox txtCNP;
        private System.Windows.Forms.Button btnAdauga;
        private System.Windows.Forms.Label lblTitlu;
    }
}