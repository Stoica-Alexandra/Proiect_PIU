﻿using LibrarieModele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NivelStocareDateProdus
{
    public interface IStocareData_Produs
    {
        void AddProdus(Produs produs);
        List<Produs> GetProduse();
        List<Produs> GetProdus(Enumerari.TipProdus categorie);
        List<Produs> GetProdus(string Nume);
        List<Produs> GetProdus(float pret_1, float pret_2);
        bool UpdateProdus(Produs produs);
        bool StergeProdus(Produs produs);
        Produs GetProdustbyIndex(int index);
    }
}
