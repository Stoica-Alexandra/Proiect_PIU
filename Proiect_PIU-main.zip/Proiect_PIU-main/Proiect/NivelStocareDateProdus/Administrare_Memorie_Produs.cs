﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibrarieModele;
using NivelStocareDateProdus;

namespace NivelStocareDateProdus
{
    public class Administrare_Memorie_Produs : IStocareData_Produs
    {
        private List<Produs> produse;

        public Administrare_Memorie_Produs()
        {
            produse = new List<Produs>();
        }

        public void AddProdus(Produs produs)
        {
            produse.Add(produs);
        }

        public List<Produs> GetProduse()
        {
            return produse;
        }
        public List<Produs> GetProdus(string Nume)
        {
            throw new Exception("Optiunea GetProdus nu este implementata");
        }
        public List<Produs> GetProdus(Enumerari.TipProdus categorie)
        {
            throw new Exception("Optiunea GetProdus by tip nu este implementata");
        }
        public List<Produs> GetProdus(float pret_1, float pret_2)
        {
            throw new Exception("Optiunea GetProdus by interval de pret nu este implementata");
        }
        public bool UpdateProdus(Produs produs)
        {
            throw new Exception("Optiunea UpdateProdus nu este implementata");
        }
        public bool StergeProdus(Produs produs)
        {
            throw new Exception("Optiunea StergeProdus nu este implementata");
        }
        public Produs GetProdustbyIndex(int index)
        {
            throw new Exception("Optiunea GetProdusbyIndex nu este implementata");
        }
    }
}
