﻿using LibrarieModele;
using NivelStocareDateProdus;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NivelStocareDateProdus
{
    public class Administrare_FisierText_Produs : IStocareData_Produs
    {
        private string numeFisier;

        public Administrare_FisierText_Produs(string numeFisier)
        {
            this.numeFisier = numeFisier;
            // se incearca deschiderea fisierului in modul OpenOrCreate
            // astfel incat sa fie creat daca nu exista
            Stream streamFisierText = File.Open(numeFisier, FileMode.OpenOrCreate);
            streamFisierText.Close();
        }
        public void AddProdus(Produs produs)
        {
            try
            {
                // instructiunea 'using' va apela la final streamWriterFisierText.Close();
                // al doilea parametru setat la 'true' al constructorului StreamWriter indica
                // modul 'append' de deschidere al fisierului
                using (StreamWriter streamWriterFisierText = new StreamWriter(numeFisier, true))
                {
                    streamWriterFisierText.WriteLine(produs.ConversieLaSir_PentruFisier());
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
        }
        public List<Produs> GetProduse()
        {
            List<Produs> produse = new List<Produs>();
            try
            {
                // instructiunea 'using' va apela streamReader.Close()
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        produse.Add(new Produs(linieFisier));
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return produse;
        }
        public List<Produs> GetProdus(string Nume)
        {
            List<Produs> produse = new List<Produs>();
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Produs produs = new Produs(linieFisier);
                        if (produs != null && produs.Nume == Nume)
                            produse.Add(produs);
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            if (produse.Count != 0)
                return produse;
            else
                return new List<Produs>(0);
        }
        public List<Produs> GetProdus(Enumerari.TipProdus categorie)
        {
            List<Produs> produse = new List<Produs>();
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Produs produs = new Produs(linieFisier);
                        if (produs != null && produs.Tip_Produs == categorie)
                            produse.Add(produs);
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            if (produse.Count != 0)
                return produse;
            else
                return new List<Produs>(0);
        }
        public List<Produs> GetProdus(float pret_1, float pret_2)
        {
            List<Produs> produse = new List<Produs>();
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Produs produs = new Produs(linieFisier);
                        if (produs != null && produs.Pret >= pret_1 && produs.Pret <= pret_2)
                            produse.Add(produs);
                    }
                    produse.Sort((produs1, produs2) => produs1.Pret.CompareTo(produs2.Pret));
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            if (produse.Count != 0)
                return produse;
            else
                return new List<Produs>(0);
        }
        public bool UpdateProdus(Produs produs)
        {
            List<Produs> produse = GetProduse();
            bool actualizareCuSucces = false;
            try
            {
                //al doilea parametru setat la 'false' al constructorului StreamWriter indica modul 'overwrite' de deschidere al fisierului
                using (StreamWriter streamWriter = new StreamWriter(numeFisier, false))
                {
                    foreach (Produs _produs in produse)
                        if (produs.IdProdus != _produs.IdProdus)
                        {
                            streamWriter.WriteLine(_produs.ConversieLaSir_PentruFisier());
                        }
                        else
                        {
                            streamWriter.WriteLine(produs.ConversieLaSir_PentruFisier());
                        }
                    actualizareCuSucces = true;
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return actualizareCuSucces;
        }
        public bool StergeProdus(Produs produs)
        {
            List<Produs> produse = GetProduse();
            bool actualizareCuSucces = false;
            try
            {
                int i = 1;
                //al doilea parametru setat la 'false' al constructorului StreamWriter indica modul 'overwrite' de deschidere al fisierului
                using (StreamWriter streamWriter = new StreamWriter(numeFisier, false))
                {
                    foreach (Produs _produs in produse)
                        if (produs.IdProdus != _produs.IdProdus)
                        {
                            _produs.IdProdus = i++;
                            streamWriter.WriteLine(_produs.ConversieLaSir_PentruFisier());
                        }
                    actualizareCuSucces = true;
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return actualizareCuSucces;
        }
        public Produs GetProdustbyIndex(int index)
        {
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Produs produs = new Produs(linieFisier);
                        if (produs != null && produs.IdProdus == index)
                            return produs;
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return null;
        }
    }
}
