﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using static LibrarieModele.Enumerari;

namespace LibrarieModele
{
    public class Produs
    {
        //constante
        private const char SEPARATOR_PRINCIPAL_FISIER = ';';
        private const char SEPARATOR_SECUNDAR_FISIER = ',';

        private const int ID = 0;
        private const int NUME = 1;
        private const int CANTITATE = 2;
        private const int PRET = 3;
        private const int NUMAR_PRODUSE_CUMPARATE = 4;
        private const int TIP_PRODUS = 5;
        private const int OPTIUNI_PRODUS = 6;

        //proprietati auto-implemented
        public static int NextId { get; set; } = 0;
        public string Nume { get; set; }
        public int IdProdus { get; set; }
        public float Pret { get; set; }
        public int Cantitate { get; set; }
        public int NumarCumparate { get; set; }
        public string InfoScurt { get {
                return Nume + " -  Pret: " + Pret.ToString() + " Optiuni produs: " + Optiuni_ProdusAsString;
            } }
        public int ProduseDisponibile { get { return Cantitate - NumarCumparate; } }
        public TipProdus Tip_Produs { get; set; }
        public ArrayList Optiuni_Produs { get; set; }
        public string Optiuni_ProdusAsString
        {
            get 
            {
                return string.Join(SEPARATOR_SECUNDAR_FISIER.ToString(), Optiuni_Produs.ToArray());
            }
        }

        //constructor cu parametrii
        public Produs(string nume = "", int cantitate = 0, float pret = 0.0F)
        {
            Nume = nume;
            Pret = pret;
            Cantitate = cantitate;
            IdProdus = ++NextId;
            NumarCumparate = 0;
        }
        public string Info()
        {
            return "#" + IdProdus.ToString() + " - " + Nume + " - Cantitate: " + Cantitate.ToString() + " Pret: "
                + Pret.ToString() + " Tip: " + Tip_Produs.ToString() + " Optiuni produs: " + Optiuni_ProdusAsString ;
        }
        //constructor cu un singur parametru de tip string care reprezinta o linie dintr-un fisier text
        public Produs(string linieFisier)
        {
            var dateFisier = linieFisier.Split(SEPARATOR_PRINCIPAL_FISIER);

            //ordinea de preluare a campurilor este data de ordinea in care au fost scrise in fisier prin apelul implicit al metodei ConversieLaSir_PentruFisier()
            this.IdProdus = Convert.ToInt32(dateFisier[ID]);
            NextId = IdProdus;
            this.Nume = dateFisier[NUME];
            this.Cantitate = int.Parse(dateFisier[CANTITATE]);
            this.Pret = Convert.ToSingle(dateFisier[PRET]);//float
            this.NumarCumparate = int.Parse(dateFisier[NUMAR_PRODUSE_CUMPARATE]);

            this.Tip_Produs = (TipProdus)Enum.Parse(typeof(TipProdus), dateFisier[TIP_PRODUS]);

            Optiuni_Produs = new ArrayList();
            //adauga mai multe elemente in lista de optiuni
            Optiuni_Produs.AddRange(dateFisier[OPTIUNI_PRODUS].Split(SEPARATOR_SECUNDAR_FISIER));
        }

        public string ConversieLaSir_PentruFisier()
        {
            string obiectProdusPentruFisier = string.Format("{1}{0}{2}{0}{3}{0}{4}{0}{5}{0}{6}{0}{7}",
                SEPARATOR_PRINCIPAL_FISIER,
                IdProdus.ToString(),
                (Nume ?? " NECUNOSCUT "),
                Cantitate.ToString(),
                Pret.ToString(),
                NumarCumparate.ToString(),
                Tip_Produs,
                Optiuni_ProdusAsString
                );
            return obiectProdusPentruFisier;
        }
    }
}
