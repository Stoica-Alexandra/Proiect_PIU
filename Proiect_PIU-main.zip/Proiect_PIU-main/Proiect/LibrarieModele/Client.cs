﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibrarieModele
{
    public class Client
    {
        //constante
        private const char SEPARATOR_PRINCIPAL_FISIER = ';';
        private const char SEPARATOR_SECUNDAR_FISIER = ',';

        private const int MAX_PRODUSE_CUMPARAT = 10;
        private const int LUNGIME_CNP = 13;
        private const int LUNGIME_NUMAR_DE_TELEFON= 10;


        private const int ID = 0;
        private const int NUME = 1;
        private const int PRENUME = 2;
        private const int COD_CNP = 3;
        private const int NR_TELEFON = 4;
        private const int BUGET = 5;
        private const int NR_PRODUSE = 6;
        private const int NR_CUMPARATE_ID = 7;

        public int[] ProduseId;//codul produselor cumparate
        //proprietati auto-implemented
        public static int NextId { get; set; } = 0;
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public float Buget { get; set; }
        public int IdClient { get; set; }
        public string CNP { get; set; }
        public string NrTelefon { get; set; }
        public int NrProduse { get; set; }

        public string NumeComplet { get { return Nume + " " + Prenume; } }
        public string ConversieLaSir_ProduseID => string.Join(SEPARATOR_SECUNDAR_FISIER.ToString(), ProduseId ?? new int[0]);// Asigura ca ProduseId nu este niciodata null

        public Client(string nume = "", string prenume = "", string _CNP = "", string nrtelefon = "", float buget = 0.0F)
        {
            Nume = nume;
            Prenume = prenume;
            CNP = _CNP;
            NrTelefon = nrtelefon;
            Buget = buget;
            NrProduse = 0;
            IdClient = ++NextId;
            ProduseId = new int[MAX_PRODUSE_CUMPARAT];
        }
        public string Info()
        {
            return "#" + IdClient + " " + Nume + " " + Prenume + " - " + NrProduse.ToString() + " produse";
        }

        public Client(string linieFisier)
        {
            var dateFisier = linieFisier.Split(SEPARATOR_PRINCIPAL_FISIER);

            //ordinea de preluare a campurilor este data de ordinea in care au fost scrise in fisier prin apelul implicit al metodei ConversieLaSir_PentruFisier()
            IdClient = Int32.Parse(dateFisier[ID]);
            NextId = IdClient;
            Nume = dateFisier[NUME];
            Prenume = dateFisier[PRENUME];
            CNP = dateFisier[COD_CNP];
            NrTelefon = dateFisier[NR_TELEFON];
            Buget = Convert.ToSingle(dateFisier[BUGET]);//float
            NrProduse = Int32.Parse(dateFisier[NR_PRODUSE]);
            ProduseId = new int[MAX_PRODUSE_CUMPARAT];
            string[] IDproduse = dateFisier[NR_CUMPARATE_ID].Split(SEPARATOR_SECUNDAR_FISIER);
            for (int i = 0; i < NrProduse; i++)
                ProduseId[i] = Int32.Parse(IDproduse[i]);
        }
        public string ConversieLaSir_PentruFisier()
        {
            string obiectClientPentruFisier = string.Format("{1}{0}{2}{0}{3}{0}{4}{0}{5}{0}{6}{0}{7}{0}{8}",
                SEPARATOR_PRINCIPAL_FISIER,
                IdClient.ToString(),
                (Nume ?? " NECUNOSCUT "),
                (Prenume ?? " NECUNOSCUT "),
                (CNP ?? " NECUNOSCUT "),
                (NrTelefon ?? " NECUNOSCUT "),
                Buget.ToString(),
                NrProduse.ToString(),
                ConversieLaSir_ProduseID
                );

            return obiectClientPentruFisier;
        }
        public bool NrMaxProduse()
        {
            if (MAX_PRODUSE_CUMPARAT == NrProduse)
                return true;
            return false;
        }
        public bool Cumparare(Produs p)
        {
            if (!NrMaxProduse() && this.Buget-p.Pret>=0)
            {
                ProduseId[NrProduse++] = p.IdProdus;
                p.NumarCumparate++;
                Buget -= p.Pret;
                return true;
            }
            return false;
        }
        public static bool ValidareCNP(string CNP)
        {
            if(CNP.Length != LUNGIME_CNP || !"1256".Contains(CNP[0]) || !CNP.All(char.IsDigit))
                return false;
            return true;
        }
        public static bool ValidareNrTelefon(string NrTelefon)
        {
            if (NrTelefon.Length != LUNGIME_NUMAR_DE_TELEFON || !NrTelefon.All(char.IsDigit))
                return false;
            return true;
        }

    }
}
