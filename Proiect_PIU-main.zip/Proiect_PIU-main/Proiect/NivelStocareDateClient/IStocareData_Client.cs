﻿using LibrarieModele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NivelStocareDateClient
{
    public interface IStocareData_Client
    {
        void AddClient(Client client);
        List<Client> GetClienti();
        Client GetClient(string Nume, string Prenume);
        Client GetClient(string str, bool ok);
        List<Client> GetClient(string Nume);
        bool UpdateClient(Client client);
        bool StergeClient(Client client);
        Client GetClientbyIndex(int index);
    }
}
