﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibrarieModele;

namespace NivelStocareDateClient
{
    public class Administrare_FisierText_Client : IStocareData_Client
    {
        private string numeFisier;

        public Administrare_FisierText_Client(string numeFisier)
        {
            this.numeFisier = numeFisier;
            // se incearca deschiderea fisierului in modul OpenOrCreate
            // astfel incat sa fie creat daca nu exista
            Stream streamFisierText = File.Open(numeFisier, FileMode.OpenOrCreate);
            streamFisierText.Close();
        }

        public void AddClient(Client client)
        {
            try
            {
                // instructiunea 'using' va apela la final streamWriterFisierText.Close();
                // al doilea parametru setat la 'true' al constructorului StreamWriter indica
                // modul 'append' de deschidere al fisierului
                using (StreamWriter streamWriterFisierText = new StreamWriter(numeFisier, true))
                {
                    streamWriterFisierText.WriteLine(client.ConversieLaSir_PentruFisier());
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
        }

        public List<Client> GetClienti()
        {
            List<Client> clienti = new List<Client>();
            try
            {
                // instructiunea 'using' va apela streamReader.Close()
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        clienti.Add(new Client(linieFisier));
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return clienti;
        }

        public Client GetClient(string Nume, string Prenume)
        {
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Client client = new Client(linieFisier);
                        if (client != null && client.Nume == Nume && client.Prenume == Prenume)
                            return client;
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return null;

        }
        public Client GetClient(string str, bool ok)
        {
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Client client = new Client(linieFisier);
                        if (client != null && client.CNP == str && ok == false)
                            return client;
                        else
                            if (client != null && client.NrTelefon == str && ok == true)
                            return client;
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return null;
        }
        public List<Client> GetClient(string Nume)
        {
            List<Client> clienti = new List<Client>();
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Client client = new Client(linieFisier);
                        if (client != null && client.Nume == Nume)
                            clienti.Add(client);
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            if (clienti.Count != 0)
                return clienti;
            else
                return new List<Client>(0);
        }
        public bool UpdateClient(Client client)
        {
            List<Client> clienti = GetClienti();
            bool actualizareCuSucces = false;
            try
            {

                //al doilea parametru setat la 'false' al constructorului StreamWriter indica modul 'overwrite' de deschidere al fisierului
                using (StreamWriter streamWriter = new StreamWriter(numeFisier, false))
                {
                    foreach (Client _client in clienti)
                        if (client.IdClient != _client.IdClient)
                        {
                            streamWriter.WriteLine(_client.ConversieLaSir_PentruFisier());
                        }
                        else
                        {
                            streamWriter.WriteLine(client.ConversieLaSir_PentruFisier());
                        }
                    actualizareCuSucces = true;
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return actualizareCuSucces;
        }
        public bool StergeClient(Client client)
        {
            List<Client> clienti = GetClienti();
            bool actualizareCuSucces = false;
            try
            {
                int i = 1;
                //al doilea parametru setat la 'false' al constructorului StreamWriter indica modul 'overwrite' de deschidere al fisierului
                using (StreamWriter streamWriter = new StreamWriter(numeFisier, false))
                {
                    foreach (Client _client in clienti)
                        if (client.IdClient != _client.IdClient)
                        {
                            _client.IdClient = i++;
                            streamWriter.WriteLine(_client.ConversieLaSir_PentruFisier());
                        }

                    actualizareCuSucces = true;
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return actualizareCuSucces;
        }
        public Client GetClientbyIndex(int index)
        {
            try
            {
                using (StreamReader streamReader = new StreamReader(numeFisier))
                {
                    string linieFisier;

                    // citeste cate o linie si creaza un obiect de tip Student
                    // pe baza datelor din linia citita
                    while ((linieFisier = streamReader.ReadLine()) != null)
                    {
                        Client client = new Client(linieFisier);
                        if (client != null && client.IdClient == index)
                            return client;
                    }
                }
            }
            catch (IOException eIO)
            {
                throw new Exception("Eroare la deschiderea fisierului. Mesaj: " + eIO.Message);
            }
            catch (Exception eGen)
            {
                throw new Exception("Eroare generica. Mesaj: " + eGen.Message);
            }
            return null;
        }
    }
}
