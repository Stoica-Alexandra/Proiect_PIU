﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibrarieModele;

namespace NivelStocareDateClient
{
    public class Administrare_Memorie_Client : IStocareData_Client
    {
        private List<Client> clienti;

        public Administrare_Memorie_Client()
        {
            clienti = new List<Client>();
        }

        public void AddClient(Client client)
        {
            clienti.Add(client);
        }

        public List<Client> GetClienti()
        {
            return clienti;
        }

        public Client GetClient(string Nume, string Prenume)
        {
            throw new Exception("Optiunea GetClient by Nume si Prenume nu este implementata");
        }
        public Client GetClient(string str, bool ok)
        {
            throw new Exception("Optiunea GetClient nu este implementata");
        }
        public List<Client> GetClient(string Nume)
        {
            throw new Exception("Optiunea GetClient by Nume nu este implementata");
        }
        public bool UpdateClient(Client client)
        {
            throw new Exception("Optiunea UpdateClient nu este implementata");
        }
        public bool StergeClient(Client client)
        {
            throw new Exception("Optiunea StergeClient nu este implementata");
        }
        public Client GetClientbyIndex(int index)
        {
            throw new Exception("Optiunea GetClientbyIndex nu este implementata");
        }
        public int NrClienti()
        {
            return GetClienti().Count;
        }
    }
}
